# Decider!

iOS iMessage app - A fun little Rock, Paper, Scissors game for making decisions when chatting with friends. 

Apple iOS Messages extension and Swift 3.0.

This was an experiment to learn the limitations of the iMessage framework. Find our learnings on [Decider! Post-mortem](http://www.simpleandpretty.co/decider).

Made by Simple & Pretty, by [Sérgio](https://sergioestevao.com "Sérgio Estêvão, Software Architect"), [Judit](https://about.me/juditlayana "UX Researcher") & [Matt](https://about.me/matthomer "App designer").

## License

Decider for iOS is an Open Source project covered by the [GNU General Public License version 3](LICENSE).
