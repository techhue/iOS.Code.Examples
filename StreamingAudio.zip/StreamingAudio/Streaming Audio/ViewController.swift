//
//  ViewController.swift
//  Streaming Audio
//
//  Created by Ben Johnson on 3/17/15.
//  Copyright (c) 2015 Bixelcog LLC. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

class ViewController: UIViewController {
    var playerController: AVPlayerViewController? = nil
    
    @IBOutlet weak var URLTextField: UITextField!
    
    fileprivate struct StoryboardConstant {
        static let playerSegue = "PlayerSegue"
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == StoryboardConstant.playerSegue {
            if let playerViewController = segue.destination as? AVPlayerViewController {
                playerController = playerViewController
            }
        }
    }
    @IBAction func handlePlayButtonPressed(_ sender: UIButton) {
        guard let text = URLTextField.text, let URL = URL(string: text) else { return }
        playerController?.player = AVPlayer(url: URL)
        playerController?.player?.play()
    }
}

