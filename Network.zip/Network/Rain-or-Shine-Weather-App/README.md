# Rain-or-Shine-Weather-App
App was made from following along in Devslopes online iOS course. Uses Alamofire to allow swift to make network calls and download JSON data from api.openweathermap.org. It then parses the JSON data to determine variables such as city name, current temp, current weather type, etc.  Once data has been saved it updates UI with the values parsed from the JSON data to give the current weather and future forecasts of the location given to the iOS simulator


Open project with the '.xcworkspace' file. This is the one that can use cocoapods and Alamofire
