import Foundation
import CoreData

@objc(Bill)
class Bill:NSManagedObject {
    
    struct Keys {
        static let Title = "title"
        static let BillID = "billID"
        static let Session = "session"
        static let IsFavorite = "isFavorite"
        static let PdfPath = "pdfPath"
        static let UpdateDate = "updateDate"
        
    }
    
    @NSManaged var title:String
    @NSManaged var billID:String
    @NSManaged var session:String
    @NSManaged var isFavorite:Bool
    @NSManaged var pdfPath:String?
    @NSManaged var updateDate:Date
    
    
    
    override init(entity:NSEntityDescription, insertInto context: NSManagedObjectContext?) {
        super.init(entity: entity, insertInto: context)
    }
    
    init(dictionary:[String:AnyObject], context:NSManagedObjectContext){
        
        //Core Data
        let entity = NSEntityDescription.entity(forEntityName: "Bill", in: context)!
        super.init(entity: entity, insertInto: context)
        
        //Dictionary
        title = dictionary[Keys.Title] as! String
        billID = dictionary[Keys.BillID] as! String
        session = dictionary[Keys.Session] as! String
        isFavorite = dictionary[Keys.IsFavorite] as! Bool
        pdfPath = dictionary[Keys.PdfPath] as? String
        updateDate = dictionary[Keys.UpdateDate] as! Date
    }
    
    
}

