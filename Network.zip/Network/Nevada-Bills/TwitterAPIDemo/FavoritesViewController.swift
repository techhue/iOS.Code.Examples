//
//  FavoritesViewController.swift
//  SunlightFoundationBills
//
//  Created by Salvador Villa on 9/6/16.
//  Copyright © 2016 Salvador Villa. All rights reserved.
//

import UIKit
import CoreData

class FavoritesViewController: UIViewController {
    
    lazy var sharedContext:NSManagedObjectContext = {
       return CoreDataStackManager.sharedInstance().managedObjectContext
    }()
    
    var bills = [Bill]()

    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        applyTheme(.dark, title: "FAVORITES")
        
        tableView.estimatedRowHeight = 68.0
        tableView.rowHeight = UITableViewAutomaticDimension

    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        //fetch the favorites and display them
        fetchFavorites()
    }
    
    func fetchFavorites() {

        let request = NSFetchRequest<Bill>(entityName: "Bill")
        let predicate = NSPredicate(format: "isFavorite == true", argumentArray: nil)
        request.predicate = predicate
        do {
            bills = try sharedContext.fetch(request)
        } catch {
            print(error)
        }
        tableView.reloadData()
    }

}

extension FavoritesViewController:UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return bills.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "favoritesCell", for: indexPath) as! FavoritesTableViewCell
        let bill = bills[(indexPath as NSIndexPath).row]
        cell.titleLabel.text = bill.title
        cell.dateLabel.text = stringFromDate(bill.updateDate)
        cell.delegate = self
        cell.tag = (indexPath as NSIndexPath).row
        
        let starImage:UIImage
        if bill.isFavorite {
            starImage = UIImage(named: "FilledStar")!
        }else {
            starImage = UIImage(named:"UnfilledStar")!
        }
        
        cell.starButton.setImage(starImage, for: UIControlState())
        cell.titleLabel.textColor = UIColor.white
        cell.backgroundColor = UIColor.clear
        return cell
    }
}

extension FavoritesViewController:FavoritesTableViewCellDelegate {
    func favoriteSelected(_ tag: Int) {
        //Check if it is favorited
        let bill = bills[tag]
        if bill.isFavorite {
            //erase the pdf if it exists
            if let pathEnding = bill.pdfPath {
                let documentsDirectory = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString
                let path = documentsDirectory.appendingPathComponent(pathEnding)
                if FileManager.default.fileExists(atPath: path) {
                    do {
                        try FileManager.default.removeItem(atPath: path)
                        print("PDF file deleted")
                    } catch {
                        print("\(error)")
                    }
                }
                bill.pdfPath = nil
            }
            bill.isFavorite = false
            
        }
        else {
            //bill is not favorite and would like to be favorite
            //note that there is no pdf path
            bill.isFavorite = true
        }
        CoreDataStackManager.sharedInstance().saveContext()
    }
}

extension FavoritesViewController:UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let billVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "billVC") as! BillViewController
        let bill = bills[(indexPath as NSIndexPath).row]
        billVC.bill = bill
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        navigationController?.pushViewController(billVC, animated: true)
        
    }
}
