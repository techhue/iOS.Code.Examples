//
//  Constants.swift
//  TwitterAPIDemo
//
//  Created by Salvador Villa on 8/31/16.
//  Copyright © 2016 Salvador Villa. All rights reserved.
//

import Foundation
import SwiftHEXColors

struct Constants {
    
    struct Sunlight {
        static let ApiScheme = "https"
        static let ApiHost = "openstates.org"
    }
    
    struct SunlightParameterKeys {
        static let ApiKey = "apikey"
        static let State = "state"
        static let LastActionSince = "last_action_since"
    }
    
    struct SunlightParameterValues {
        static let ApiKey = "6104932b60364f59adfea89137fd7686"
        static let Nevada = "nv"
        static let TwentyFifteenSince = "2015-01-01"
    }
    
    struct SunlightResponseKeys {
        static let Title = "title"
        static let Session = "session"
        static let BillID = "bill_id"
        static let Versions = "versions"
        static let Url = "url"
        static let UpdatedAt = "updated_at"
    }
    
    struct UserDefaults {
        static let LastRefresh = "lastRefresh"
    }
    struct Colors {
        static let Yellow = UIColor(hexString: "F3E358")!
    }
}