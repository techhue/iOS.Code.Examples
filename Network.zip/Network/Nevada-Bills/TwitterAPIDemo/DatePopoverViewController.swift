//
//  DatePopoverViewController.swift
//  TwitterAPIDemo
//
//  Created by Salvador Villa on 9/13/16.
//  Copyright © 2016 Salvador Villa. All rights reserved.
//

import UIKit

protocol DatePopoverViewControllerDelegate {
    func fetchBillsInDateRange(_ from:Date, to:Date)
}

class DatePopoverViewController: UIViewController {

    var delegate:DatePopoverViewControllerDelegate?
    
    @IBOutlet weak var fromDatePicker: UIDatePicker!
    @IBOutlet weak var toDatePicker: UIDatePicker!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //don't allow user to place a future date, no bills exist
        toDatePicker.maximumDate = Date()
        fromDatePicker.maximumDate = Date()
       
    }

    @IBAction func okButtonTouched(_ sender: AnyObject) {
        if  fromDatePicker.date.timeIntervalSince1970 > toDatePicker.date.timeIntervalSince1970 {
            showAlert("Dates are not chronological", message: "The FROM date should come before the TO date!")
        }else {
        delegate?.fetchBillsInDateRange(fromDatePicker.date, to: toDatePicker.date)
        dismiss(animated: true, completion: nil)
        }
    }
    
    

}
