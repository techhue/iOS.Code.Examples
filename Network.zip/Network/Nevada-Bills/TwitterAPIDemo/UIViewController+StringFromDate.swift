//
//  UIViewController+StringFromDate.swift
//  SunlightFoundationBills
//
//  Created by Salvador Villa on 9/6/16.
//  Copyright © 2016 Salvador Villa. All rights reserved.
//

import Foundation
import UIKit

extension UIViewController {
    func stringFromDate(_ date:Date) -> String {
        let formatter =  DateFormatter()
        formatter.dateStyle = .long
        formatter.timeStyle = .none
        return formatter.string(from: date)
    }
}
