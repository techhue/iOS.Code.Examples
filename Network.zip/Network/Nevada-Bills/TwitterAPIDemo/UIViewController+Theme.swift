//
//  UIViewController+Theme.swift
//  NVPolitics727
//
//  Created by Salvador Villa on 7/27/16.
//  Copyright © 2016 Salvador Villa. All rights reserved.
//

import Foundation
import UIKit


enum Theme {
    case dark
}

extension UIViewController {
    func applyTheme(_ theme:Theme, title:String){
        
        switch theme {
        case .dark:
            navigationController?.navigationBar.barStyle = .black
            navigationController?.navigationBar.barTintColor = UIColor(hexString: "1A1A1B")
            navigationController?.navigationBar.isTranslucent = false
            //Remove 1px line
            navigationController?.navigationBar.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
            navigationController?.navigationBar.shadowImage = UIImage()
            view.backgroundColor = UIColor(hexString:"121414")
        default:
            print("No recognized theme chosen")
        }
        
        //Title, background color, & font
        self.title = title
        let font = UIFont(name: ".SFUIText-Medium", size: 14)!
        navigationController!.navigationBar.titleTextAttributes = [NSFontAttributeName:font]
        
    }
}
