//
//  BillsModel.swift
//  SunlightFoundationBills
//
//  Created by Salvador Villa on 9/1/16.
//  Copyright © 2016 Salvador Villa. All rights reserved.
//

import Foundation

class BillsModel: NSObject {
    
    static let sharedIstance = BillsModel() //singleton
    
    var titles = [String]()
    var sessions = [String]()
    var billIDs = [String]()
    
    
}