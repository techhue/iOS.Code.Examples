//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"


let dateString = "2016-01-15 20:03:29"
let formatter = NSDateFormatter()
formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
//formatter.dateStyle = .LongStyle
//formatter.timeStyle = .NoStyle
let date:NSDate
date = formatter.dateFromString(dateString)!
print(date)

func stringFromDate(date:NSDate) -> String {
    let formatter =  NSDateFormatter()
    formatter.dateStyle = .ShortStyle
    formatter.timeStyle = .NoStyle
    return formatter.stringFromDate(date)
}

let n = "\(NSDate())"


let index = n.characters.indexOf(" ")
n.substringToIndex(index!)

stringFromDate(date)

//"2015-01-01"
