//
//  BillViewController.swift
//  SunlightFoundationBills
//
//  Created by Salvador Villa on 9/1/16.
//  Copyright © 2016 Salvador Villa. All rights reserved.
//

import UIKit
import CoreData

class BillViewController: UIViewController {
    
    @IBOutlet weak var webView: UIWebView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    var bill:Bill!
    
    var billData:Data?
    
    lazy var sharedContext:NSManagedObjectContext = {
        return CoreDataStackManager.sharedInstance().managedObjectContext
    }()
    
    let documentsDirectory = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addStarButton()
        applyTheme(.dark, title: "\(bill.billID)")
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        activityIndicator.startAnimating()
        getPDF()
    }
    
    func addStarButton() {
        let starImage:UIImage
        if bill.isFavorite {
            starImage = UIImage(named: "FilledStarRIghtBarButton")!
        }else {
            starImage = UIImage(named: "UnfilledStarRIghtBarButton")!
        }
        let rightButton =  UIBarButtonItem(image: starImage, style: .plain, target: self, action: #selector(BillViewController.barStarTouched))
        self.navigationItem.rightBarButtonItem = rightButton
    }
    
    //setting the bill as favorite or not
    func barStarTouched() {
        if bill.isFavorite {
            bill.isFavorite = false
            
            if let pathEnding = bill.pdfPath  {
                let fileManager = FileManager.default
                let filePath = documentsDirectory.appendingPathComponent(pathEnding)
                if  fileManager.fileExists(atPath: filePath) {
                    do {
                        try fileManager.removeItem(atPath: filePath)
                    } catch{
                        print(error)
                    }
                }
                bill.pdfPath = nil
                
            }
            CoreDataStackManager.sharedInstance().saveContext()
            let starButton = navigationItem.rightBarButtonItem!
            starButton.image = UIImage(named:"UnfilledStarRIghtBarButton")!
            
        }
        else {
            
            _ = FileManager.default
            let date = Date()
            let filePath = documentsDirectory.appendingPathComponent("\(date)")
            
            if let data = billData {
                bill.isFavorite = true
                try? data.write(to: URL(fileURLWithPath: filePath), options: [.atomic])
                bill.pdfPath = "\(date)"
                CoreDataStackManager.sharedInstance().saveContext()
                let starButton = navigationItem.rightBarButtonItem!
                starButton.image = UIImage(named:"FilledStarRIghtBarButton")!
                
            }else {
                //failed to save
                let alertVC = UIAlertController(title: "No PDF to save.", message: "No file available.", preferredStyle: .alert)
                let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil)
                alertVC.addAction(okAction)
                present(alertVC, animated: true, completion: nil )
                
            }
        }
    }
    
    /*
     * Method checks if the PDF is locally saved. Otherwise downloads it from the net and saves it
     * Should only save if it is a favorite.
     */
    func getPDF(){
        
        //Check if we have a path to load

        var unableToLoadFromMemory = true
        
        if let path = bill.pdfPath {
            let readPath = self.documentsDirectory.appendingPathComponent(path)
            if let pdfData = try? Data(contentsOf: URL(fileURLWithPath: readPath)){
                unableToLoadFromMemory = false
                billData = pdfData

                webView.load(pdfData, mimeType: "application/pdf", textEncodingName: "utf-8", baseURL: URL(string: "a")!)
            }
        }
        if unableToLoadFromMemory {
            let session = bill.session
            let billID = bill.billID
            
            SunlightClient.sharedInstance.getPDFURLForBill(Constants.SunlightParameterValues.Nevada, session: session, billID: billID) { (success,urlString) in
                if success{
                    let url = URL(string: urlString!)!
                    //Download the pdf then load it
                    let pdfDownloader = Downloader.downloadPDF(url, completionHandlerForDownloadPDF: { (success, pdfData) in
                        if success {
                            //save the pdf data and load it
                            if self.bill.isFavorite {
                                let date = Date()
                                let writePath = self.documentsDirectory.appendingPathComponent("\(date)")
                                self.bill.pdfPath = "\(date)"
                                CoreDataStackManager.sharedInstance().saveContext()
                                
                                try? pdfData!.write(to: URL(fileURLWithPath: writePath), options: [.atomic])
                            }
                            self.billData = pdfData!
                            performUIUpdatesOnMain({ 
                                self.webView.load(pdfData!, mimeType: "application/pdf", textEncodingName: "utf-8", baseURL: URL(string:"a")!)
                            })
                           
                        }
                    })
                    
                }
                else {
                    //No success downloading bill show an alert
                    let alert = UIAlertController(title: "Internet is down.", message: "Try downloading the bill later.", preferredStyle: .actionSheet)
                    let action = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: { (action) in
                        self.navigationController?.popViewController(animated: true)
                    })
                    alert.addAction(action)
                    performUIUpdatesOnMain({
                        self.present(alert, animated: true, completion: nil)
                        
                    })
                }
            }
        }
    }
}




extension BillViewController:UIWebViewDelegate {
    func webViewDidStartLoad(_ webView: UIWebView) {
        webView.isHidden = true
        
    }
    
    func webViewDidFinishLoad(_ webView: UIWebView) {
        webView.isHidden = false
        activityIndicator.stopAnimating()
    }
}
