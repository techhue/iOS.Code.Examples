//
//  UIViewController+ShowAlert.swift
//  TwitterAPIDemo
//
//  Created by Salvador Villa on 9/14/16.
//  Copyright © 2016 Salvador Villa. All rights reserved.
//

import UIKit

extension UIViewController {
    
    func showAlert(_ title:String, message:String){
        let alertVC  = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertVC.addAction(okAction)
        present(alertVC, animated: true, completion: nil)
    }
}
