//
//  SunlightClient.swift
//  SunlightFoundationBills
//
//  Created by Salvador Villa on 9/1/16.
//  Copyright © 2016 Salvador Villa. All rights reserved.
//

import Foundation
import UIKit


class SunlightClient: NSObject {
    
    static let sharedInstance = SunlightClient()
    
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    
    func getBillsFromState(_ state:String, since:String, completionHandlerForGetBillsFromState:@escaping (_ success:Bool, _ titles:[String]?, _ sessions:[String]?, _ billIDs:[String]?, _ updateDates:[Date]?) -> Void){
        
        //1. Set up the parameters
        let parameters:[String:AnyObject] = [Constants.SunlightParameterKeys.ApiKey:Constants.SunlightParameterValues.ApiKey as AnyObject, Constants.SunlightParameterKeys.State:state as AnyObject, Constants.SunlightParameterKeys.LastActionSince:since as AnyObject]
        
        //2. Build the URL
        let url = appDelegate.sunlightURLFromParameters(parameters, withPathExtension: "/api/v1//bills")
        
        
        let session = URLSession.shared
        let request = URLRequest(url: url)
        
        let task = session.dataTask(with: request, completionHandler: { (data, response, error) in
            
            //Network code errors
            func sendError(_ error:String){
                print(error)
                //let userInfo = [NSLocalizedDescriptionKey:error]
                completionHandlerForGetBillsFromState(false, nil,nil, nil, nil)
            }
            
            guard error == nil else {
                sendError((error?.localizedDescription)!)
                return
            }
            
            guard let statusCode = (response as? HTTPURLResponse)?.statusCode else {
                sendError("No status code given.")
                return
            }
            
            if statusCode < 200 || statusCode > 299 {
                print("The statusCode is \(statusCode)")
                sendError("Status code is other than 2xx!")
                return
            }
            
            guard let data = data else {
                sendError("No data returned")
                return
            }
            
            let parsedResult:Any!
            do {
                parsedResult = try JSONSerialization.jsonObject(with: data, options: .allowFragments)
            } catch {
                print("json error \(error)")
                sendError("Could not parse JSON data")
                return
            }
            
            
            
            guard let bills = parsedResult as? [[String:AnyObject]] else {
                sendError("format of JSON is failing.")
                return
            }
            
            var theTitles = [String]()
            var theSessions = [String]()
            var theBillIDs = [String]()
            var theUpdateDates = [Date]()
            
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
            
            for billData in bills {
                
                guard let dateString = billData[Constants.SunlightResponseKeys.UpdatedAt] as? String else {
                    continue
                }
                
                if let aTitle = billData[Constants.SunlightResponseKeys.Title] as? String, let aSession = billData[Constants.SunlightResponseKeys.Session] as? String, let aBillID = billData[Constants.SunlightResponseKeys.BillID] as? String, let anUpdateDate = formatter.date(from: dateString) {
                    theTitles.append(aTitle)
                    theSessions.append(aSession)
                    theBillIDs.append(aBillID)
                    theUpdateDates.append(anUpdateDate)
                }
            }
            
            completionHandlerForGetBillsFromState(true, theTitles, theSessions, theBillIDs, theUpdateDates)
        }) 
        task.resume()
    }
    
    func getPDFURLForBill(_ state:String, session:String, billID:String, completionHandlerForGetPDF:@escaping (_ success:Bool, _ pdfURL:String?) -> Void) {
        //1. set up the parameters
        let parameters:[String:AnyObject] = [Constants.SunlightParameterKeys.ApiKey:Constants.SunlightParameterValues.ApiKey as AnyObject]
        
        //2. build the url
        let url = appDelegate.sunlightURLFromParameters(parameters, withPathExtension: "/api/v1//bills/\(state)/\(session)/\(billID)/")
        
        let session = URLSession.shared
        let request = URLRequest(url: url)
        
        let task = session.dataTask(with: request, completionHandler: { (data, response, error) in
            
            func sendError(_ error:String){
                print(error)
                completionHandlerForGetPDF(false, nil)
            }
            
            guard error == nil else {
                sendError((error?.localizedDescription)!)
                return
            }
            
            guard let statusCode = (response as? HTTPURLResponse)?.statusCode
                else {
                    sendError("No status code returned")
                    return
            }
            
            if statusCode < 200 || statusCode > 299 {
                sendError("The status code is \(statusCode). Status code erorr")
                return
            }
            
            guard let data = data else {
                sendError("No data returned.")
                return
            }
            
            let parsedResult:[String:Any]!
            do{
                parsedResult = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! [String:Any]
            } catch{
                sendError("JSON parsing error: \(error)")
                return
            }
            
            guard let versionsArray = parsedResult[Constants.SunlightResponseKeys.Versions] as? [[String:AnyObject]] else {
                sendError("\(Constants.SunlightResponseKeys.Versions) key not working")
                return
            }
            
           
            guard let url  = versionsArray.first![Constants.SunlightResponseKeys.Url] as? String else {
                sendError("\(Constants.SunlightResponseKeys.Url) key not working")
                return
            }
            
            //check that it is a pdf file
            guard url.hasSuffix(".pdf") else {
                sendError("no link provided in JSON. NOT A PDF.")
                return
            }
            
            completionHandlerForGetPDF(true, url)
            
        }) 
        task.resume()
        
        
    }
    
    
}
