
import Foundation

class Downloader {
    class func downloadPDF(_ URL: Foundation.URL, completionHandlerForDownloadPDF:@escaping (_ success:Bool, _ pdfData:Data?) -> Void) {
        let sessionConfig = URLSessionConfiguration.default
        let session = URLSession(configuration: sessionConfig, delegate: nil, delegateQueue: nil)
        var request = URLRequest(url: URL)
        request.httpMethod = "GET"
        
        let task = session.dataTask(with: request, completionHandler: { (data, response, error) in
            
            func sendError(_ message:String){
                print(message)
                completionHandlerForDownloadPDF(false, nil)
            }
            
            guard error == nil else {
                sendError("Error returned: \(error?.localizedDescription)")
                return
            }
            
            guard let statusCode = (response as? HTTPURLResponse)?.statusCode , statusCode >= 200 && statusCode < 300 else {
                sendError("StatusCode error. Not in 2xx!")
                return
            }
            
            guard let data = data else {
                sendError("Data returned is nil.")
                return
                
            }
            
            completionHandlerForDownloadPDF(true, data)
            
        }) 
        task.resume()
    }
}
