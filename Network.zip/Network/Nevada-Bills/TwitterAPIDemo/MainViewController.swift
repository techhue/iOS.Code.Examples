//
//  MainViewController.swift
//  TwitterAPIDemo
//
//  Created by Salvador Villa on 8/31/16.
//  Copyright © 2016 Salvador Villa. All rights reserved.
//

import UIKit
import CoreData
import SwiftHEXColors
import Foundation

class MainViewController: UIViewController {
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    @IBOutlet weak var tableView: UITableView!
    let refreshButton = UIButton(type: .custom)
    var bills = [Bill]()
    
    lazy var refreshControl: UIRefreshControl = {
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(MainViewController.handleRefresh(_:)), for: UIControlEvents.valueChanged)
        
        return refreshControl
    }()
    
    
    
    lazy var sharedContext:NSManagedObjectContext = {
        return CoreDataStackManager.sharedInstance().managedObjectContext
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.addSubview(self.refreshControl)
        
        fetchBills()
        if bills.count == 0 {
            tableView.isHidden = true
            activityIndicator.startAnimating()
            loadData()
        }else {
            //See if new data popped up since last load
            refreshControl.beginRefreshingManually()
            handleRefresh(refreshControl)
        }
        applyTheme(.dark, title: "NV BILLS")
        tableView.estimatedRowHeight = 68.0
        tableView.rowHeight = UITableViewAutomaticDimension
        
        //add a right bar button item
        let dateBarButtonItem = UIBarButtonItem(title: "DATE RANGE", style: .plain, target: self, action:#selector(MainViewController.showPopover))
        navigationItem.rightBarButtonItem = dateBarButtonItem
    }
    
    func showPopover(){
        
        let dateVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "datePopoverVC") as! DatePopoverViewController
        dateVC.modalPresentationStyle = .popover
        dateVC.delegate = self
        let popoverVC = dateVC.popoverPresentationController
        popoverVC?.permittedArrowDirections = .any
        popoverVC?.delegate = self
        popoverVC?.barButtonItem = navigationItem.rightBarButtonItem!
        
        
        present(dateVC, animated: true, completion: nil)
        
    }
    
    func handleRefresh(_ refreshControl:UIRefreshControl){
        
        //Get more bills since last refresh
        let defaults = UserDefaults.standard
        if let date = defaults.object(forKey: Constants.UserDefaults.LastRefresh) as? Date {
            
            let dateString = "\(date)"
            let index = dateString.characters.index(of: " ")!
            let sinceString = dateString.substring(to: index)
            
            
            //make a network call with a new date
            SunlightClient.sharedInstance.getBillsFromState(Constants.SunlightParameterValues.Nevada, since: sinceString) { (success, titles, sessions, billIDs, updateDates) in
                if success {
                    let newSinceDate = Date()
                    let defaults = UserDefaults.standard
                    defaults.set(newSinceDate, forKey: Constants.UserDefaults.LastRefresh)
                    
                    //Here we neeed to add the data to the CoreData Model
                    if titles!.count > 0 {
                        for index in 0...titles!.count-1 {
                            
                            let properties:[String:AnyObject] = [Bill.Keys.Title:titles![index] as AnyObject,Bill.Keys.Session:sessions![index] as AnyObject, Bill.Keys.BillID:billIDs![index] as AnyObject, Bill.Keys.IsFavorite:false as AnyObject, Bill.Keys.UpdateDate:updateDates![index] as AnyObject]
                            let bill = Bill(dictionary: properties, context: self.sharedContext)
                            
                            self.bills.append(bill)
                        }
                        CoreDataStackManager.sharedInstance().saveContext()
                    }
                    
                    performUIUpdatesOnMain({
                        self.tableView.reloadData()
                    })
                }
                else {
                    self.showAlert("Unable to update", message: "Try again later")
                }
                refreshControl.endRefreshing()
            }
        }
    }
    
    //From Core Data
    func fetchBills() {
        bills = [Bill]()
        let request = NSFetchRequest<Bill>(entityName: "Bill")
        let sortDescriptor = NSSortDescriptor(key: "updateDate", ascending: false)
        request.sortDescriptors = [sortDescriptor]
        do{
            bills = try sharedContext.fetch(request)
        } catch{
            print(error)
        }
        print(bills.count)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableView.reloadData()
    }
    
    //From API
    func loadData(){
        SunlightClient.sharedInstance.getBillsFromState(Constants.SunlightParameterValues.Nevada, since:Constants.SunlightParameterValues.TwentyFifteenSince) { (success, titles, sessions, billIDs, updateDates) in
            
            performUIUpdatesOnMain({
                self.activityIndicator.stopAnimating()
            })
            if success{
                
                //Here we neeed to add the data to the CoreData Model
                for index in 0...titles!.count-1 {
                    
                    let properties:[String:AnyObject] = [Bill.Keys.Title:titles![index] as AnyObject,Bill.Keys.Session:sessions![index] as AnyObject, Bill.Keys.BillID:billIDs![index] as AnyObject, Bill.Keys.IsFavorite:false as AnyObject, Bill.Keys.UpdateDate:updateDates![index] as AnyObject]
                    let bill = Bill(dictionary: properties, context: self.sharedContext)
                    
                    self.bills.append(bill)
                }
                CoreDataStackManager.sharedInstance().saveContext()
                
                let defaults = UserDefaults.standard
                defaults.set(Date(), forKey: Constants.UserDefaults.LastRefresh)
                
                performUIUpdatesOnMain({
                    self.tableView.isHidden = false
                    self.refreshButton.isHidden = true
                    self.tableView.reloadData()
                })
            }
            else{
                // HIDE TABLE VIEW AND PLACE A REFRESH BUTTON
                let alert = UIAlertController(title: "Internet is down.", message: "Try downloading bills later.", preferredStyle: .actionSheet)
                let action = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: { (action) in
                    if self.refreshButton.isEnabled{
                        self.displayRefreshButton()
                    }else {
                        self.refreshButton.isHidden = false
                        self.refreshButton.isEnabled = true
                    }
                })
                alert.addAction(action)
                performUIUpdatesOnMain({ 
                    self.present(alert, animated: true, completion: nil)

                })
              
            }
        }
    }
    
    //show a refresh button when no data is available from api
    func displayRefreshButton() {
        tableView.isHidden = true
        refreshButton.isHidden = false
        refreshButton.backgroundColor = UIColor.darkGray
        refreshButton.setTitleColor( UIColor(red: 243/255, green: 227/255, blue: 88/255, alpha: 1.0), for: UIControlState())
        refreshButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16)
        refreshButton.addTarget(self, action: #selector(MainViewController.refreshButtonPushed), for: .touchUpInside)
        refreshButton.setTitle("TAP TO RELOAD.", for: UIControlState())
        refreshButton.layer.cornerRadius = 6
        refreshButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(refreshButton)
        
        let xConstraint = NSLayoutConstraint(item: refreshButton, attribute: .centerX, relatedBy: .equal, toItem: view, attribute: .centerX, multiplier: 1.0, constant: 0)
        let yConstraint = NSLayoutConstraint(item: refreshButton, attribute: .centerY, relatedBy: .equal, toItem: view, attribute: .centerY, multiplier: 1.0, constant: 0)
        let wConstraint = NSLayoutConstraint(item: refreshButton, attribute: .width, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 0, constant: 150)
        let hConstraint = NSLayoutConstraint(item: refreshButton, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 0, constant: 50)
        
        let constraints = [xConstraint,yConstraint,wConstraint,hConstraint]
        view.addConstraints(constraints)
        
    }
    
    func refreshButtonPushed(){
        activityIndicator.startAnimating()
        refreshButton.isHidden = true
        refreshButton.isEnabled = false
        loadData()
    }
}

extension MainViewController:DatePopoverViewControllerDelegate {
    func fetchBillsInDateRange(_ from: Date, to: Date) {
        
        //1. Fetch bills and update the bills parameter
        let request = NSFetchRequest<Bill>(entityName: "Bill")
        
        let sortDescriptor = NSSortDescriptor(key: "updateDate", ascending: false)
        
        let datePredicate = NSPredicate(format: "(updateDate >= %@) AND (updateDate <= %@)", from as CVarArg, to as CVarArg)
        request.predicate = datePredicate
        request.sortDescriptors = [sortDescriptor]
        //billsHelper in case there are no bills returned for date range, alert user that no bills returned then show all bills
        var billsHelper = [Bill]()
       
        do {
            billsHelper = try sharedContext.fetch(request) 
        } catch {
            print(error)
        }
        
        if billsHelper.count > 0 {
            bills = billsHelper
            tableView.reloadData()
        }
        else {
            showAlert("No bills in date range.", message: "Showing all bills.")
        }

        
    }
}


extension MainViewController:UIPopoverPresentationControllerDelegate {
    func adaptivePresentationStyle(for controller: UIPresentationController) -> UIModalPresentationStyle {
        return .none
    }
}



extension MainViewController:UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return bills.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TitleTableViewCell
        let bill = bills[(indexPath as NSIndexPath).row]
        cell.titleLabel.text = bill.title
        cell.delegate = self
        cell.tag = (indexPath as NSIndexPath).row //keeps track for toggling favorite
        cell.dateLabel.text = stringFromDate(bill.updateDate)
        
        let starImage:UIImage
        if bill.isFavorite {
            starImage = UIImage(named: "FilledStar")!
        }else {
            starImage = UIImage(named: "UnfilledStar")!
        }
        
        cell.starButton.setImage(starImage, for: UIControlState())
        cell.titleLabel.textColor = UIColor.white
        cell.backgroundColor = UIColor.clear
        return cell
    }
}



extension MainViewController:UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let billVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "billVC") as! BillViewController
        billVC.bill = bills[(indexPath as NSIndexPath).row]
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        navigationController?.pushViewController(billVC, animated: true)
    }
    
}

extension MainViewController:TitleTableViewCellDelegate {
    func favoriteSelected(_ tag:Int) {
        let bill = bills[tag]
        if bill.isFavorite {
            //erase the pdf if it exists
            if let pathEnding = bill.pdfPath {
                
                let documentsDirectory = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString
                let path = documentsDirectory.appendingPathComponent(pathEnding)
                if FileManager.default.fileExists(atPath: path) {
                    do {
                        try FileManager.default.removeItem(atPath: path)
                        
                    } catch {
                        print("\(error)")
                    }
                }
                bill.pdfPath = nil
            }
            bill.isFavorite = false
            
        }else {
            bill.isFavorite = true
        }
        CoreDataStackManager.sharedInstance().saveContext()
    }
}
