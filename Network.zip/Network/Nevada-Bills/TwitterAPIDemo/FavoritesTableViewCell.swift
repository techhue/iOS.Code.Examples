//
//  FavoritesTableViewCell.swift
//  SunlightFoundationBills
//
//  Created by Salvador Villa on 9/6/16.
//  Copyright © 2016 Salvador Villa. All rights reserved.
//

import UIKit

protocol FavoritesTableViewCellDelegate: class {
    func favoriteSelected(_ tag:Int)
}

class FavoritesTableViewCell: UITableViewCell {

    @IBOutlet weak var dateLabel: UILabel!
    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var starButton: UIButton!
    weak var delegate:FavoritesTableViewCellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    @IBAction func starButtonTouched(_ sender: UIButton) {
        delegate?.favoriteSelected(self.tag)
        
        if starButton.imageView?.image == UIImage(named: "FilledStar"){
            starButton.setImage(UIImage(named: "UnfilledStar"), for: UIControlState())
        }else {
            starButton.setImage(UIImage(named: "FilledStar"), for: UIControlState())
            starButton.imageView?.image = UIImage(named: "FilledStar")
        }
    }
}
