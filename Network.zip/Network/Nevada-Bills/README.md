# Nevada-Bills
NEVADA BILLS

NEVADA BILLS allows users to download bills from the Nevada Legislature. Each bill can be saved by tapping on the star and can be read offline (can see these bills under favorites tab). Each bill is represented by a table view cell. It displays the date last modified in yellow and the title of the bill. The user can also check for new bills by pulling to refresh on the table view.

All data comes from the Sunlight Foundation APIs which collects and organizes data from state legislatures. The app uses core data to save the bills.

![alt tag](https://i.imgsafe.org/49efe40037.png)
![alt tag](https://i.imgsafe.org/49f41333e9.png)
![alt tag](https://i.imgsafe.org/49efe0890f.png)
