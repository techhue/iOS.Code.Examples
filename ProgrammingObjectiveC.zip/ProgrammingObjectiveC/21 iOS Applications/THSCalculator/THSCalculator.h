//
//  THSCalculator.h
//  THSCalculator
//
//  Created by naga on 1/5/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "THSFraction.h"

@interface THSCalculator : NSObject

@property (strong, nonatomic) THSFraction *operand1, *operand2, *accumulator;
-(THSFraction *) performOperation: (char) op;
-(void) clear;

@end
