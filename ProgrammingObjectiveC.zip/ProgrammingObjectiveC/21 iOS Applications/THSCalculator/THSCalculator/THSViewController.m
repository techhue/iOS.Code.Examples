//
//  THSViewController.m
//  THSCalculator
//
//  Created by naga on 1/5/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import "THSViewController.h"
#import "THSLabel.h"
#import "THSButton.h"
#import "THSCalculator.h"

@interface THSViewController ()
{
    NSArray *buttonValues;
}

@end

@implementation THSViewController
{
    char op;
    int currentNumber;
    BOOL firstOperand, isNumerator;
    THSCalculator *myCalculator;
    NSMutableString *displayString;
}

@synthesize display;
@synthesize button;



- (void)loadView
{
    [super loadView];
    buttonValues = [NSArray arrayWithObjects:@"0", @"1", @"2", @"3", @"4", @"5", @"6", @"7", @"8",@"9",
                    @"Over",
                    @"=",
                    @"-", @"%", @"+", @"*",
                    @"C", nil];
    display = [[THSLabel alloc] initWithFrame:CGRectMake(20, 10, 280, 50)];
    display.backgroundColor = [UIColor lightGrayColor];
    [self.view addSubview:display];
    NSInteger originX, originY, width, height;
    NSInteger horizontalSpace = 20;
    NSInteger verticalSpace = 20;
    originX = 20;
    width = 75;
    originY = 400;
    height = 30;
    for(int count = 0; count < [buttonValues count]; count++)
    {
        button = [THSButton buttonWithType:UIButtonTypeRoundedRect];
        button.frame = CGRectMake(originX, originY, width, height);
        [button setTitle:[buttonValues objectAtIndex:count] forState:UIControlStateNormal];
        [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        if(count < 10)
        {
            [button addTarget:self
                       action:@selector(clickDigit:)
             forControlEvents:UIControlEventTouchDown];
        }
        else if (count == 10)
            [button addTarget:self
                       action:@selector(clickOver)
             forControlEvents:UIControlEventTouchDown];
        else if (count == 11)
            [button addTarget:self
                       action:@selector(clickEquals)
             forControlEvents:UIControlEventTouchDown];
        else if (count == 12)
            [button addTarget:self
                       action:@selector(clickMinus)
             forControlEvents:UIControlEventTouchDown];
        else if (count == 13)
            [button addTarget:self
                       action:@selector(clickDivide)
             forControlEvents:UIControlEventTouchDown];
        else if (count == 14)
            [button addTarget:self
                       action:@selector(clickPlus)
             forControlEvents:UIControlEventTouchDown];
        else if (count == 15)
            [button addTarget:self
                       action:@selector(clickMultiply)
             forControlEvents:UIControlEventTouchDown];
        else if (count == 16)
            [button addTarget:self
                       action:@selector(clickClear)
             forControlEvents:UIControlEventTouchDown];
        
        [self.view addSubview:button];
        if((count+1) % 3 == 0)
        {
            originX = 20;
            originY = originY - verticalSpace - height;
        }
        else
        {
            originX = originX + horizontalSpace + width;
        }
    }
    
    firstOperand = YES;
    isNumerator = YES;
    displayString = [NSMutableString stringWithCapacity: 40];
    myCalculator = [[THSCalculator alloc] init];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)click:(THSButton*)sender

{
    NSMutableString *expression;
    if([sender.titleLabel.text isEqualToString:@"C"])
    {
        expression = (NSMutableString*) @"";
    }
    {
        [expression appendString:sender.titleLabel.text];
    }
    display.text = expression;
    display.textAlignment = NSTextAlignmentRight;
}

-(void) processDigit: (int) digit
{
    currentNumber = currentNumber * 10 + digit;
    [displayString appendString:[NSString stringWithFormat: @"%i", digit]];
    display.text = displayString;
}

- (IBAction) clickDigit: (UIButton *) sender
{
    int digit = [sender.titleLabel.text intValue];
    [self processDigit: digit];
}

-(void) processOp: (char) theOp
{
    NSString *opStr;
    op = theOp;
    switch (theOp)
    {
        case '+':
            opStr = @" + ";
            break;
        case '-':
            opStr = @" – ";
            break;
        case '*':
            opStr = @" ∞ ";
            break;
        case '/':
            opStr = @" ÷ ";
        break;
    }
    [self storeFracPart];
    firstOperand = NO;
    isNumerator = YES;
    [displayString appendString: opStr];
    display.text = displayString;
}

-(void) storeFracPart
{
    if (firstOperand)
    {
        if (isNumerator)
        {
            myCalculator.operand1.numerator = currentNumber;
            myCalculator.operand1.denominator = 1; // e.g. 3 * 4/5 =
        }
        else
                myCalculator.operand1.denominator = currentNumber;
        }
        else if (isNumerator)
        {
            myCalculator.operand2.numerator = currentNumber;
            myCalculator.operand2.denominator = 1; // e.g. 3/2 * 4 =
        }
        else
        {
                myCalculator.operand2.denominator = currentNumber;
                firstOperand = YES;
        }
            currentNumber = 0;
}

-(IBAction) clickOver
{
    [self storeFracPart];
    isNumerator = NO;
    [displayString appendString: @"/"];
    display.text = displayString;
}

-(IBAction) clickPlus
{
    [self processOp: '+'];
}

-(IBAction) clickMinus
{
    [self processOp: '-'];
}

-(IBAction) clickMultiply
{
    [self processOp: '*'];
}

-(IBAction) clickDivide
{
    [self processOp: '/'];
}

// Misc. Keys

-(IBAction) clickEquals
{
    if ( firstOperand == NO )
    {
        [self storeFracPart];
        [myCalculator performOperation: op];
        [displayString appendString: @" = "];
        [displayString appendString: [myCalculator.accumulator convertToString]];
        display.text = displayString;
        currentNumber = 0;
        isNumerator = YES; firstOperand = YES; [displayString setString: @""];
    }
}
-(IBAction) clickClear
{
    isNumerator = YES;
    firstOperand = YES;
    currentNumber = 0;
    [myCalculator clear];
    [displayString setString: @""];
    display.text = displayString;
}

@end
