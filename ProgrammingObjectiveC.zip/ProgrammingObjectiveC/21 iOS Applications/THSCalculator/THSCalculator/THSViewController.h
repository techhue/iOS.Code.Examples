//
//  THSViewController.h
//  THSCalculator
//
//  Created by naga on 1/5/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@class THSLabel;
@class THSButton;
@class THSCalculator;

@interface THSViewController : UIViewController

@property (nonatomic, strong) THSLabel *display;

@property (nonatomic, strong) THSButton *button;

-(void) processDigit: (int) digit;
-(void) processOp: (char) theOp;
-(void) storeFracPart;
// Numeric keys

-(IBAction) clickDigit: (UIButton *) sender;

// Arithmetic Operation keys
-(IBAction) clickPlus;
-(IBAction) clickMinus; -(IBAction) clickMultiply;
-(IBAction) clickDivide;

// Misc. Keys
-(IBAction) clickOver;
-(IBAction) clickEquals;
-(IBAction) clickClear;

- (IBAction)click:(THSButton*)sender;

@end
