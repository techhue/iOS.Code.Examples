//
//  THSCalculator.m
//  THSCalculator
//
//  Created by naga on 1/5/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import "THSCalculator.h"

@implementation THSCalculator

@synthesize operand1, operand2, accumulator;

-(id) init
{
    self = [super init];
    if (self) {
        operand1 = [[THSFraction alloc] init];
        operand2 = [[THSFraction alloc] init];
        accumulator = [[THSFraction alloc] init];
    }
    return self;
}

-(void) clear
{
    accumulator.numerator = 0;
    accumulator.denominator = 0;
}

-(THSFraction *) performOperation: (char) op
{
    THSFraction *result;
    switch (op)
    {
        case '+':
            result = [operand1 add: operand2];
            break;
        case '-':
            result = [operand1 subtract: operand2];
            break;
        case '*':
            result = [operand1 multiply: operand2];
            break;
        case '/':
            result = [operand1 divide: operand2];
        break;
    }
    accumulator.numerator = result.numerator;
    accumulator.denominator = result.denominator;
    return accumulator;
}

@end
