//
//  THSFraction.h
//  THSCalculator
//
//  Created by naga on 1/5/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface THSFraction : NSObject

@property int numerator, denominator;

-(void) print;
-(void) setTo: (int) n over: (int) d; 
-(THSFraction *) add: (THSFraction *) f;
-(THSFraction *) subtract: (THSFraction *) f;
-(THSFraction *) divide: (THSFraction *) f;
-(THSFraction *) multiply: (THSFraction *) f;
-(void) reduce;
-(double) convertToNum;
-(NSString *) convertToString;

@end
