//
//  main.m
//  17.0.0 - Memory Management and Automatic Reference Counting
//
//  Created by naga on 1/4/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"
#import "THSFraction.h"

/**************************************************************************
* Object References and the Autorelease Pool
*
***************************************************************************/

int main(int argc, char *argv[])
{
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    THSFraction *frac1 = [[THSFraction alloc] init];
    THSFraction *frac2 = [[THSFraction alloc] init];
    // Set 1st fraction to 2/3
    [frac1 setNumerator: 2];
    [frac1 setDenominator: 3];
    // Set 2nd fraction to 3/7
    [frac2 setNumerator: 3];
    [frac2 setDenominator: 7];
    // Display the fractions
    NSLog (@"First fraction is:");
    [frac1 print];
    NSLog (@"Second fraction is:");
    [frac2 print];
    [frac1 release];
    [frac2 release];
    [pool drain];
    return 0;
}
