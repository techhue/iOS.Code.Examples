//
//  main.m
//  15.3.0 - Numbers, Strings, and Collections
//
//  Created by naga on 1/4/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"

/***********************************************************************
 *  Dictionary Objects
 *
 ************************************************************************/

int main(int argc, char *argv[])
{
    @autoreleasepool {
        NSMutableDictionary *glossary = [NSMutableDictionary dictionary];
        // Store three entries in the glossary
        [glossary setObject: @"A class defined so other classes can inherit from it"
                     forKey: @"abstract class" ];
        [glossary setObject: @"To implement all the methods defined in a protocol"
                     forKey: @"adopt"];
        [glossary setObject: @"Storing an object for later use"
                     forKey: @"archiving"];
        // Retrieve and display them
        NSLog (@"abstract class: %@", [glossary objectForKey: @"abstract class"]);
        NSLog (@"adopt: %@", [glossary objectForKey: @"adopt"]);
        NSLog (@"archiving: %@", [glossary objectForKey: @"archiving"]);
        
        // Enumerating a Dictionary
        glossary = [NSDictionary dictionaryWithObjectsAndKeys:
                    @"A class defined so other classes can inherit from it",
                    @"abstract class",
                    @"To implement all the methods defined in a protocol",
                    @"adopt",
                    @"Storing an object for later use",
                    @"archiving",
                    nil];
        // Print all key-value pairs from the dictionary
        for ( NSString *key in glossary )
            NSLog (@"%@: %@", key, [glossary objectForKey: key]);
         
    }
    return 0;
}
