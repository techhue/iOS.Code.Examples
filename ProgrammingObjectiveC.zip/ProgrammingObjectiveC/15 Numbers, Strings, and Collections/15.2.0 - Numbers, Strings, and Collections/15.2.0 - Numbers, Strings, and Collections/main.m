//
//  main.m
//  15.2.0 - Numbers, Strings, and Collections
//
//  Created by naga on 1/4/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"

/***********************************************************************
*  Array Objects
*
 ************************************************************************/

int main(int argc, char *argv[])
{
    int i;
    @autoreleasepool {
        // Create an array to contain the month names
        NSArray *monthNames = [NSArray arrayWithObjects:
                               @"January",
                               @"February",
                               @"March",
                               @"April",
                               @"May",
                               @"June",
                               @"July",
                               @"August",
                               @"September",
                               @"October",
                               @"November",
                               @"December",
                               nil ];
        // Now list all the elements in the array
        NSLog (@"Month Name");
        NSLog (@"===== ====");
        for (i = 0; i < 12; ++i)
            NSLog (@" %2i %@", i + 1, [monthNames objectAtIndex: i]);
    }
    return 0;
}
