//
//  main.m
//  15.2.1 - Numbers, Strings, and Collections
//
//  Created by naga on 1/4/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"

/***********************************************************************
 *  Array Objects With MutableArray
 *
 ************************************************************************/

int main(int argc, char *argv[])
{
    @autoreleasepool {
        NSMutableArray *numbers = [NSMutableArray array];
        NSNumber *myNumber;
        int i;
        // Create an array with the number 0-9
        for (i = 0; i < 10; ++i )
        {
            myNumber = [NSNumber numberWithInteger: i];
            [numbers addObject: myNumber];
        }
        
        // Sequence through the array and display the values
        for (i = 0; i < 10; ++i )
        {
            myNumber = [numbers objectAtIndex: i];
            NSLog (@"%@", myNumber);
        }
        // Look how NSLog can display it with a single %@ format
        NSLog (@"====== Using a single NSLog");
        NSLog (@"%@", numbers);
    }
    return 0;
}
