//
//  main.m
//  15.2.2 - Numbers, Strings, and Collections
//
//  Created by naga on 1/4/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"
#import "THSAddressCard.h"

/***********************************************************************
 *  Address Card
 *
 ************************************************************************/

int main(int argc, char *argv[])
{
    @autoreleasepool {
        NSString *aName = @"Julia Kochan";
        NSString *aEmail = @"jewls337@axlc.com";
        THSAddressCard *card1 = [[THSAddressCard alloc] init];
        [card1 setName: aName];
        [card1 setEmail: aEmail];
        [card1 print];
    }
    return 0;
}
