//
//  THSAddressBook.h
//  15.2.4 - Numbers, Strings, and Collections
//
//  Created by naga on 1/4/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "THSAddressCard.h"

@interface THSAddressBook : NSObject

@property (nonatomic, copy) NSString *bookName;
@property (nonatomic, strong) NSMutableArray *book;

-(id) initWithName: (NSString *) name;
-(void) addCard: (THSAddressCard *) theCard;
-(NSUInteger) entries;
-(void) list;

@end
