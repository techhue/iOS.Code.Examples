//
//  main.m
//  15.2.4 - Numbers, Strings, and Collections
//
//  Created by naga on 1/4/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"
#import "THSAddressBook.h"

/***********************************************************************
 *  Address Card and Address Book
 *
 ************************************************************************/

int main(int argc, char *argv[])
{
    @autoreleasepool {
        NSString *aName = @"Julia Kochan";
        NSString *aEmail = @"jewls337@axlc.com";
        NSString *bName = @"Tony Iannino";
        NSString *bEmail = @"tony.iannino@techfitness.com"; NSString *cName = @"Stephen Kochan";
        NSString *cEmail = @"steve@classroomM.com"; NSString *dName = @"Jamie Baker";
        NSString *dEmail = @"jbaker@classroomM.com";
        THSAddressCard *card1 = [[THSAddressCard alloc] init];
        THSAddressCard *card2 = [[THSAddressCard alloc] init];
        THSAddressCard *card3 = [[THSAddressCard alloc] init];
        THSAddressCard *card4 = [[THSAddressCard alloc] init];
        // Set up a new address book
        THSAddressBook *myBook = [[THSAddressBook alloc] initWithName: @"Linda’s Address Book"];
        NSLog (@"Entries in address book after creation: %i", [myBook entries]);
        
        // Now set up four address cards
        [card1 setName: aName andEmail: aEmail];
        [card2 setName: bName andEmail: bEmail];
        [card3 setName: cName andEmail: cEmail];
        [card4 setName: dName andEmail: dEmail];
        
        // Add the cards to the address book
        [myBook addCard: card1];
        [myBook addCard: card2];
        [myBook addCard: card3];
        [myBook addCard: card4];
        
        NSLog (@"Entries in address book after adding cards: %i", [myBook entries]);
        // List all the entries in the book now
        [myBook list];
    }
    return 0;
}
