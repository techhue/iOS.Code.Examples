//
//  main.m
//  8.2.1 - Inheritance
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"

/************************************************************************
 * Which Method Is Selected?
 *
 *************************************************************************/

// ClassA declaration and definition
@interface ClassA: NSObject
{
    int x; // Will be inherited by subclasses
}

-(void) initVar;
-(void) printVar;
@end

////////////////////////////
@implementation ClassA

-(void) initVar
{
    x = 100;
}

-(void) printVar
{
    NSLog (@"x = %i", x);
}

@end

// ClassB declaration and definition

@interface ClassB: ClassA

-(void) initVar;
-(void) printVar;

@end

////////////////////////////

@implementation ClassB

-(void) initVar
{
    x = 200;
}

-(void) printVar
{
    // added method
    NSLog (@"x = %i", x);
}

@end
////////////////////////////

int main(int argc, char *argv[])
{
    @autoreleasepool {
        ClassA *a = [[ClassA alloc] init];
        ClassB *b = [[ClassB alloc] init];
        [a initVar]; // uses ClassA method
        [a printVar]; // reveal value of x;
        [b initVar]; // use overriding ClassB method
        [b printVar]; // reveal value of x;
    }
    return 0;
}
