//
//  main.m
//  8.1.0 - Inheritance
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"
#import "THSRectangle.h"
#import "THSSquare.h"

/************************************************************************
 * Extension Through Inheritance: Adding New Methods
 *
 *************************************************************************/

int main(int argc, char *argv[])
{
    @autoreleasepool {
        /*THSRectangle *myRect = [[THSRectangle alloc] init];
        [myRect setWidth: 5 andHeight: 8];
        NSLog (@"Rectangle: w = %i, h = %i", myRect.width, myRect.height);
        NSLog (@"Area = %i, Perimeter = %i", [myRect area], [myRect perimeter]);*/
        THSSquare *mySquare = [[THSSquare alloc] init];
        [mySquare setSide: 5];
        NSLog (@"Square s = %i", [mySquare side]);
        NSLog (@"Area = %i, Perimeter = %i", [mySquare area], [mySquare perimeter]);
    }
    return 0;
}
