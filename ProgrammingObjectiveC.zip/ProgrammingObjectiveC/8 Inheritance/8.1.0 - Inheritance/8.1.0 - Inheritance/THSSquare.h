//
//  THSSquare.h
//  8.1.0 - Inheritance
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "THSRectangle.h"

@interface THSSquare : THSRectangle

-(void) setSide: (int) s;
-(int) side;

@end
