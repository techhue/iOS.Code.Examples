//
//  THSRectangle.m
//  8.1.0 - Inheritance
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import "THSRectangle.h"

@implementation THSRectangle

@synthesize width, height;

-(void) setWidth: (int) w andHeight: (int) h
{
    width = w;
    height = h;
}

-(int) area
{
    return width * height;
}

-(int) perimeter
{
    return (width + height) * 2;
}

@end
