//
//  main.m
//  8.0.0 - Inheritance
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"

/************************************************************************
* Simple example to illustrate inheritance
*
*************************************************************************/


// ClassA declaration and definition
@interface ClassA: NSObject
{
    int x;
}

-(void) initVar;

@end

@implementation ClassA

-(void) initVar
{
    x = 100;
}

@end
// Class B declaration and definition
@interface ClassB : ClassA

-(void) printVar;

@end

@implementation ClassB

-(void) printVar
{
    NSLog (@"x = %i", x);
}

@end


int main(int argc, char *argv[])
{
    @autoreleasepool {
        ClassB *b = [[ClassB alloc] init];
        [b initVar];
        [b printVar];
    }
        return 0;
}
