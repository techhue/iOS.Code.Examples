//
//  main.m
//  8.2.0 - Inheritance
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"

/************************************************************************
 * Overriding Methods
 *
 *************************************************************************/

// ClassA declaration and definition
@interface ClassA: NSObject
{
    int x; // Will be inherited by subclasses
}

-(void) initVar;
@end

////////////////////////////
@implementation ClassA

-(void) initVar
{
    x = 100;
}

@end

// ClassB declaration and definition

@interface ClassB: ClassA

-(void) initVar;
-(void) printVar;

@end

////////////////////////////

@implementation ClassB

-(void) initVar
{
    x = 200;
}

-(void) printVar
{
    // added method
    NSLog (@"x = %i", x);
}

@end
////////////////////////////

int main(int argc, char *argv[])
{
    @autoreleasepool {
        ClassB *b = [[ClassB alloc] init];
        [b initVar]; // uses overriding method in B
        [b printVar]; // reveal value of x;
    }
        return 0;
}
