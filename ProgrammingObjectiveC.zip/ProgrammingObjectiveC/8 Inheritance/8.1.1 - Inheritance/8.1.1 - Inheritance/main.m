//
//  main.m
//  8.1.1 - Inheritance
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"
#import "THSXYPoint.h"
#import "THSRectangle.h"

/************************************************************************
 * The @class Directive
 *
 *************************************************************************/

int main(int argc, char *argv[])
{
    @autoreleasepool {
        /*THSRectangle *myRect = [[THSRectangle alloc] init];
        THSXYPoint *myPoint = [[THSXYPoint alloc] init];
        [myPoint setX: 100 andY: 200];
        [myRect setWidth: 5 andHeight: 8]; 
         myRect.origin = myPoint;
        NSLog (@"Rectangle w = %i, h = %i", myRect.width, myRect.height);
        NSLog (@"Origin at (%i, %i)", myRect.origin.x, myRect.origin.y);
        NSLog (@"Area = %i, Perimeter = %i", [myRect area], [myRect perimeter]);*/
        
        THSRectangle *myRect = [[THSRectangle alloc] init];
        THSXYPoint *myPoint = [[THSXYPoint alloc] init];
        [myPoint setX: 100 andY: 200];
        [myRect setWidth: 5 andHeight: 8];
        myRect.origin = myPoint;
        NSLog (@"Origin at (%i, %i)", myRect.origin.x, myRect.origin.y);
        [myPoint setX: 50 andY: 50];
        NSLog (@"Origin at (%i, %i)", myRect.origin.x, myRect.origin.y);
    }
    return 0;
}
