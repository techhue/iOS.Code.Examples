//
//  THSRectangle.h
//  8.1.1 - Inheritance
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <Foundation/Foundation.h>

@class THSXYPoint;

@interface THSRectangle : NSObject

@property int width, height;

- (THSXYPoint*)origin;
- (void)setOrigin:(THSXYPoint *)pt;
- (void)setWidth:(int) w andHeight:(int) h;
- (int)area;
- (int)perimeter;

@end
