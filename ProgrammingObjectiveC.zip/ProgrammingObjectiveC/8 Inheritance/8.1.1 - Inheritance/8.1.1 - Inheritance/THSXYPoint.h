//
//  THSXYPoint.h
//  8.1.1 - Inheritance
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface THSXYPoint : NSObject

@property int x, y;

-(void) setX: (int) xVal andY: (int) yVal;

@end
