//
//  THSRectangle.m
//  8.1.1 - Inheritance
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import "THSRectangle.h"
#import "THSXYPoint.h"

@implementation THSRectangle
{
    THSXYPoint *origin;
}

@synthesize width, height;

- (void)setWidth:(int)w andHeight:(int)h
{
    width = w;
    height = h;
}

- (void)setOrigin:(THSXYPoint *)pt
{
    origin = pt;
}

- (int)area
{
    return width * height;
}

- (int)perimeter
{
    return (width +  height) * 2;
}

- (THSXYPoint*) origin
{
    return origin;
}


@end
