//
//  main.m
//  7.4.0 - More on Classes
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"
#import "THSFraction.h"

/***********************************************************************************
 * Allocating and Returning Objects from Methods
 *
 ************************************************************************************/


int main(int argc, char *argv[])
{
    @autoreleasepool {
        THSFraction *aFraction = [[THSFraction alloc] init];
        THSFraction *bFraction = [[THSFraction alloc] init];
        THSFraction *resultFraction;
        [aFraction setTo: 1 over: 4]; // set 1st fraction to 1/4
        [bFraction setTo: 1 over: 2]; // set 2nd fraction to 1/2
        [aFraction print];
        NSLog (@"+");
        [bFraction print];
        NSLog (@"=");
        resultFraction = [aFraction add: bFraction];
        [resultFraction print];
    }
    return 0;
}
