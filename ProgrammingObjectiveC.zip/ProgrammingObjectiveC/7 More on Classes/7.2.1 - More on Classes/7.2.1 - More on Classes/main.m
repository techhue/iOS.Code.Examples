//
//  main.m
//  7.2.1 - More on Classes
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"
#import "THSFraction.h"

/***********************************************************************************
 * Operations on Fractions
 *
 ************************************************************************************/


int main(int argc, char *argv[])
{
    @autoreleasepool {
        THSFraction *aFraction = [[THSFraction alloc] init];
        THSFraction *bFraction = [[THSFraction alloc] init];
        // Set two fractions to 1/4 and 1/2 and add them together
        [aFraction setTo: 1 over: 4];
        [bFraction setTo: 1 over: 2];
        // Print the results
        [aFraction print]; NSLog (@"+");
        [bFraction print]; NSLog (@"=");
        [aFraction add: bFraction];
        [aFraction print]; }
    return 0;
}
