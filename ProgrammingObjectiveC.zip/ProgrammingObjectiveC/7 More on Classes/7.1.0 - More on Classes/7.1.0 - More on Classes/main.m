//
//  main.m
//  7.1.0 - More on Classes
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"
#import "THSFraction.h"

/***********************************************************************************
 * Synthesized Accessor Methods
 *
 ************************************************************************************/


int main(int argc, char *argv[])
{
    @autoreleasepool {
        THSFraction *myFraction = [[THSFraction alloc] init];
        // set fraction to 1/3
        [myFraction setNumerator: 1];
        [myFraction setDenominator: 3];
        // display the fraction
        NSLog (@"The value of myFraction is:");
        [myFraction print];
    }
    return 0;
}
