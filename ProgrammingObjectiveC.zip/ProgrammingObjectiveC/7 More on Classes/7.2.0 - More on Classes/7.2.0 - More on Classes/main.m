//
//  main.m
//  7.2.0 - More on Classes
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"
#import "THSFraction.h"

/***********************************************************************************
 * Multiple Arguments to Methods
 *
 ************************************************************************************/

int main(int argc, char *argv[])
{
    @autoreleasepool {
        THSFraction *aFraction = [[THSFraction alloc] init];
        [aFraction setTo: 100 over: 200];
        [aFraction print];
        [aFraction setTo: 1 over: 3];
        [aFraction print];
    }
    return 0;
}
