//
//  main.m
//  5.0.0 - Program Looping
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

/*****************************************************************************
* Program to calculate the eighth triangular number
*
******************************************************************************/

#import "THSAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        int triangularNumber;
        triangularNumber = 1 + 2 + 3 + 4 + 5 + 6 + 7 + 8;
        NSLog (@"The eighth triangular number is %i", triangularNumber);
    }
    return 0;
}
