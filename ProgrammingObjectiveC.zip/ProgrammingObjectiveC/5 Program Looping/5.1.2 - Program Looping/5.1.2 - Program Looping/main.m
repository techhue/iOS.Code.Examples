//
//  main.m
//  5.1.2 - Program Looping
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"

/*****************************************************************************
* Keyboard Input
*
******************************************************************************/

int main(int argc, char *argv[])
{
    @autoreleasepool {
        int n, number, triangularNumber;
        NSLog (@"What triangular number do you want?");
        scanf ("%i", &number);
        triangularNumber = 0;
        for ( n = 1; n <= number; ++n )
            triangularNumber += n;
        NSLog (@"Triangular number %i is %i\n", number, triangularNumber);
    }
    return 0;
}
