//
//  main.m
//  5.2.1 - Program Looping
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"

/*****************************************************************************
 * Find the greatest common divisor of two nonnegative integers
 *
 ******************************************************************************/

int main(int argc, char *argv[])
{
    @autoreleasepool {
        unsigned int u, v, temp;
        NSLog (@"Please type in two nonnegative integers.");
        u = 150;
        v = 35;
        while ( v != 0 )
        {
            temp = u % v; u = v;
            v = temp;
        }
        NSLog (@"Their greatest common divisor is %u", u); }
    return 0;
}
