//
//  main.m
//  5.1.3 - Program Looping
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"

/*****************************************************************************
 * Nested for Loops
 *
 ******************************************************************************/

int main(int argc, char *argv[])
{
    @autoreleasepool {
        int n, number, triangularNumber, counter;
        for ( counter = 1; counter <= 5; ++counter )
        {
            NSLog (@"What triangular number do you want?");
            scanf ("%i", &number);
            triangularNumber = 0;
            for ( n = 1; n <= number; ++n )
                triangularNumber += n;
            NSLog (@"Triangular number %i is %i", number, triangularNumber);
        }
    }
    return 0;
}
