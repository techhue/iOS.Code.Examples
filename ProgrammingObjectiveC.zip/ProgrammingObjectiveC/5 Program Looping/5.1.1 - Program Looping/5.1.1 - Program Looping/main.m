//
//  main.m
//  5.1.1 - Program Looping
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"

/*****************************************************************************
 * Program to generate a table of triangular numbers
 *
 ******************************************************************************/

int main(int argc, char *argv[])
{
    @autoreleasepool {
        int n, triangularNumber;
        NSLog (@"TABLE OF TRIANGULAR NUMBERS");
        NSLog (@" n Sum from 1 to n");
        NSLog (@"-- ---------------");
        triangularNumber = 0;
        for ( n = 1; n <= 10; ++n )
        {
            triangularNumber += n;
            NSLog(@" %i        %i", n, triangularNumber);
        }
    }
    return 0;
}
