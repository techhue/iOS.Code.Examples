//
//  main.m
//  5.2.0 - Program Looping
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"

/*****************************************************************************
 * The while Statement
 *
 ******************************************************************************/

int main(int argc, char *argv[])
{
    @autoreleasepool {
        int count = 1;
        while ( count <= 5 )
        {
            NSLog (@"%i", count); ++count;
        }
    }
    return 0;
}
