//
//  main.m
//  5.2.2 - Program Looping
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"

/*****************************************************************************
 * Program to reverse the digits of a number
 *
 ******************************************************************************/

int main(int argc, char *argv[])
{
    @autoreleasepool {
        int number, right_digit;
        NSLog (@"Enter your number.");
        
        number = 13579;
        while ( number != 0 )
        {
            right_digit = number % 10;
            NSLog (@"%i", right_digit);
            number /= 10;
        }
    }
    return 0;
}
