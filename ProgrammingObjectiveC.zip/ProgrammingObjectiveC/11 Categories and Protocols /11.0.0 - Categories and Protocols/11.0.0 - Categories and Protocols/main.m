//
//  main.m
//  11.0.0 - Categories and Protocols
//
//  Created by naga on 1/4/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"
#import "THSFraction.h"
#import "THSFraction+MathOps.h"

/***************************************************************************
* Categories
*
****************************************************************************/

int main(int argc, char *argv[])
{
    @autoreleasepool {
        THSFraction *a = [[THSFraction alloc] init];
        THSFraction *b = [[THSFraction alloc] init];
        THSFraction *result;
        [a setTo: 1 over: 3];
        [b setTo: 2 over: 5];
        [a print]; NSLog (@" +"); [b print];
        NSLog (@"-----");
        result = [a add: b];
        [result print];
        NSLog (@"\n");
        [a print]; NSLog (@" -"); [b print];
        NSLog (@"-----");
        result = [a sub: b];
        [result print];
        NSLog (@"\n");
        [a print]; NSLog (@" *"); [b print];
        NSLog (@"-----");
        result = [a mul: b];
        [result print];
        NSLog (@"\n");
        [a print]; NSLog (@" /"); [b print];
        NSLog (@"-----");
        result = [a div: b];
        [result print];
        NSLog (@"\n");
    }
    return 0;
}
