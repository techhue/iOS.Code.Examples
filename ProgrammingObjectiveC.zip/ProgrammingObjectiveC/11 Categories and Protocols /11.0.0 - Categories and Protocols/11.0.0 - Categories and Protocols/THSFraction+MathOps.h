//
//  THSFraction+MathOps.h
//  11.0.0 - Categories and Protocols
//
//  Created by naga on 1/4/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import "THSFraction.h"

@interface THSFraction (MathOps)

-(THSFraction *) add: (THSFraction *) f;
-(THSFraction *) mul: (THSFraction *) f;
-(THSFraction *) sub: (THSFraction *) f;
-(THSFraction *) div: (THSFraction *) f;

@end
