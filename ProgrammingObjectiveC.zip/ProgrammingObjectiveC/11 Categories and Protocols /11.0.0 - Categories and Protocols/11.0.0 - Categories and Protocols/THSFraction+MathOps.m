//
//  THSFraction+MathOps.m
//  11.0.0 - Categories and Protocols
//
//  Created by naga on 1/4/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import "THSFraction+MathOps.h"

@implementation THSFraction (MathOps)

-(THSFraction *) add: (THSFraction *) f
{
    // To add two fractions:
    // a/b + c/d = ((a*d) + (b*c)) / (b * d)
    THSFraction *result = [[THSFraction alloc] init];
    result.numerator = (self.numerator * f.denominator) + (self.denominator * f.numerator);
    result.denominator = self.denominator * f.denominator;
    [result reduce];
    return result;
}

-(THSFraction *) sub: (THSFraction *) f
{
    // To sub two fractions:
    // a/b - c/d = ((a*d) - (b*c)) / (b * d)
    THSFraction *result = [[THSFraction alloc] init];
    result.numerator = (self.numerator * f.denominator) - (self.denominator * f.numerator);
    result.denominator = self.denominator * f.denominator;
    [result reduce];
    return result;
}

-(THSFraction *) mul: (THSFraction *) f
{
    THSFraction *result = [[THSFraction alloc] init];
    result.numerator = self.numerator * f.numerator;
    result.denominator = self.denominator * f.denominator;
    [result reduce];
    return result;
}

-(THSFraction *) div: (THSFraction *) f
{
    THSFraction *result = [[THSFraction alloc] init];
    result.numerator = self.numerator * f.denominator;
    result.denominator = self.denominator * f.numerator;
    [result reduce];
    return result;
}

@end
