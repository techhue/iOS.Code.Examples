//
//  THSFraction.h
//  6.0.7(A) - Making Decisions
//
//  Created by Intelligene on 1/6/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Calculator: NSObject

// accumulator methods
-(void) setAccumulator: (double) value;
-(void) clear;
-(double) accumulator;

// arithmetic methods
-(void) add: (double) value;
-(void) subtract: (double) value;
-(void) multiply: (double) value;
-(void) divide: (double) value;

@end
