//
//  main.m
//  6.0.7(A) - Making Decisions
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"
#import "THSFraction.h"

/**********************************************************************************
 * Program to evaluate simple expressions of the form value operator value
 * Insert interface and implementation sections for Calculator class here
 *
 ***********************************************************************************/



int main(int argc, char *argv[])
{
    @autoreleasepool {
        double value1, value2;
        char operator;
        Calculator *deskCalc = [[Calculator alloc] init];
        NSLog (@"Type in your expression.");
        //scanf ("%lf %c %lf", &value1, &operator, &value2);
        value1 = 198.7;
        operator = '/';
        value2 = 0;
        [deskCalc setAccumulator: value1];
        if ( operator == '+' )
            [deskCalc add: value2];
        else if ( operator == '-' )
            [deskCalc subtract: value2];
        else if ( operator == '*' )
            [deskCalc multiply: value2];
        else if ( operator == '/' )
            if ( value2 == 0 )
                NSLog (@"Division by zero.");
            else
                [deskCalc divide: value2];
            else
                NSLog (@"Unknown operator.");
        NSLog (@"%.2f", [deskCalc accumulator]);
    }
    return 0;
}
