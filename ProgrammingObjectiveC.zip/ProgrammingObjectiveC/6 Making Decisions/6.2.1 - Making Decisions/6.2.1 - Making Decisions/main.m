//
//  main.m
//  6.2.1 - Making Decisions
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"

/**********************************************************************************
 * Program to generate a table of prime numbers
 * second version using BOOL type and predefined values
 ***********************************************************************************/

int main(int argc, char *argv[])
{
    @autoreleasepool {
        int p, d; BOOL isPrime;
        for ( p = 2; p <= 50; ++p )
        {
            isPrime = YES;
            for ( d = 2; d < p; ++d )
                if ( p % d == 0 )
                    isPrime = NO;
            if ( isPrime == YES )
                NSLog (@"%i ", p);
        }
    }
    return 0;
}
