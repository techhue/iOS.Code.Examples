//
//  main.m
//  6.0.5 - Making Decisions
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"

/**********************************************************************************
 * Program to implement the sign function
 *
 ***********************************************************************************/

int main(int argc, char *argv[])
{
    @autoreleasepool {
        int number, sign = 0;
        NSLog (@"Please type in a number: ");
        //scanf ("%i", &number);
        number = 100;
        if ( number < 0 )
            sign = -1;
        else if ( number == 0 )
            sign = 0;
        else // Must be positive sign = 1;
            NSLog (@"Sign = %i", sign);
    }
    return 0;
}
