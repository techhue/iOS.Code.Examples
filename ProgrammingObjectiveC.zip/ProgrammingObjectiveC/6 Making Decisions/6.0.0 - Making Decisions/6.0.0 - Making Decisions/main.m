//
//  main.m
//  6.0.0 - Making Decisions
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"

/**********************************************************************************
* Calculate the absolute value of an integer
*
***********************************************************************************/

int main(int argc, char *argv[])
{
    @autoreleasepool {
        int number;
        NSLog (@"Type in your number: ");
        //scanf ("%i", &number);
        number = -100;
        if ( number < 0 )
            number = -number;
        NSLog (@"The absolute value is %i", number);
    }
    return 0;
}
