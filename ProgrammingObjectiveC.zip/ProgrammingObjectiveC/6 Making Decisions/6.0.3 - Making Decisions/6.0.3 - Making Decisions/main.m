//
//  main.m
//  6.0.3 - Making Decisions
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"

/**********************************************************************************
 * Program to determine if a number is even or odd (Ver.2)
 *
 ***********************************************************************************/


int main(int argc, char *argv[])
{
    @autoreleasepool {
        int number_to_test, remainder;
        NSLog (@"Enter your number to be tested:");
        //scanf ("%i", &number_to_test);
        number_to_test = 15;
        remainder = number_to_test % 2;
        if ( remainder == 0 )
            NSLog (@"The number is even.");
        else
            NSLog (@"The number is odd.");
    }
    return 0;
}
