//
//  main.m
//  18.2.0 - Copying Objects
//
//  Created by naga on 1/4/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"
#import "THSFraction.h"

/****************************************************************************
 * Implementing the <NSCopying> Protocol
 *
 *****************************************************************************/


int main(int argc, char *argv[])
{
    @autoreleasepool {
        THSFraction *f1 = [[THSFraction alloc] init];
        THSFraction *f2;
        [f1 setTo: 2 over: 5];
        f2 = [f1 copy];
        [f2 setTo: 1 over: 3];
        [f1 print];
        [f2 print];
    }
    return 0;
}
