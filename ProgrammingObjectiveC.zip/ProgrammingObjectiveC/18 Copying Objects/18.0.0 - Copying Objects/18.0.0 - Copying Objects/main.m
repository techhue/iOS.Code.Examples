//
//  main.m
//  18.0.0 - Copying Objects
//
//  Created by naga on 1/4/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"

/****************************************************************************
* The copy and mutableCopy Methods
*
*****************************************************************************/

int main(int argc, char *argv[])
{
    @autoreleasepool {
        NSMutableArray *dataArray = [NSMutableArray
                                     arrayWithObjects: @"one", @"two", @"three", @"four", nil];
        NSMutableArray *dataArray2; // simple assignment
        dataArray2 = dataArray;
        [dataArray2 removeObjectAtIndex: 0];
        NSLog (@"dataArray: ");
        for ( NSString *elem in dataArray )
            NSLog (@" %@", elem);
        NSLog (@"dataArray2: ");
        for ( NSString *elem in dataArray2 )
            NSLog (@"dataArray: ");
        // try a copy, then remove the first element from the copy
        dataArray2 = [dataArray mutableCopy];
        [dataArray2 removeObjectAtIndex: 0];
        NSLog (@"dataArray: ");
        for ( NSString *elem in dataArray )
            NSLog (@" %@", elem);
        NSLog (@"dataArray2: ");
        for ( NSString *elem in dataArray2 )
            NSLog (@" %@", elem);
    }
    return 0;
}
