//
//  main.m
//  4.1.0 - Data Types and Expressions
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        int a = 100;
        int b = 2;
        int c = 25;
        int d = 4;
        int result;
        result = a - b;
        NSLog (@"a - b = %i", result);
        result = b * c; // multiplication NSLog (@"b * c = %i", result);
        result = a / c; // division NSLog (@"a / c = %i", result);
        result = a + b * c; // precedence NSLog (@"a + b * c = %i", result);
        NSLog (@"a * b + c * d = %i", a * b + c * d); }
    return 0;
}
