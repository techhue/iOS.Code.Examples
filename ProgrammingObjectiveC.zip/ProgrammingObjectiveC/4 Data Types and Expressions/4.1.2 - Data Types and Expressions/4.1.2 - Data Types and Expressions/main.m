//
//  main.m
//  4.1.2 - Data Types and Expressions
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"

/*****************************************************************************
 * The modulus operator
 *
 ******************************************************************************/

int main(int argc, char *argv[])
{
    @autoreleasepool {
        int a = 25, b = 5, c = 10, d = 7;
        NSLog (@"a %% b = %i", a%b);
        NSLog (@"a %% c = %i", a%c);
        NSLog (@"a %% d = %i", a%d);
        NSLog (@"a / d * d + a %% d = %i", a / d * d + a % d);
        }
    return 0;
}
