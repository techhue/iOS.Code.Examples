//
//  THSAddressCard.h
//  15.2.2 - Numbers, Strings, and Collections
//
//  Created by naga on 1/4/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface THSAddressCard : NSObject <NSCoding, NSCopying>

@property (copy, nonatomic) NSString *name, *email;

-(void) print;
-(void) setName: (NSString *) theName andEmail: (NSString *) theEmail;
-(NSComparisonResult) compareNames: (id) element;
// Additional method for NSCopying protocol
-(void) assignName: (NSString *) theName andEmail: (NSString *) theEmail;

@end
