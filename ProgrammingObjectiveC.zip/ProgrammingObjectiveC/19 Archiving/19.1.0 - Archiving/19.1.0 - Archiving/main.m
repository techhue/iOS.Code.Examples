//
//  main.m
//  19.1.0 - Archiving
//
//  Created by naga on 1/4/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"

/**********************************************************************
 * Archiving with NSKeyedArchiver
 * Wrting into file and reading from file
 *
 ***********************************************************************/

int main(int argc, char *argv[])
{
    @autoreleasepool {
        NSDictionary *glossary =
        [NSDictionary dictionaryWithObjectsAndKeys:
         @"A class defined so other classes can inherit from it",
         @"abstract class",
         @"To implement all the methods defined in a protocol",
         @"adopt",
         @"Storing an object for later use",
         @"archiving",
         nil];
        [NSKeyedArchiver archiveRootObject: glossary toFile: @"glossary.archive"];
        glossary = [NSKeyedUnarchiver unarchiveObjectWithFile: @"glossary.archive"];
        for ( NSString *key in glossary )
            NSLog (@"%@: %@", key, [glossary objectForKey: key]);
    }
    return 0;
}
