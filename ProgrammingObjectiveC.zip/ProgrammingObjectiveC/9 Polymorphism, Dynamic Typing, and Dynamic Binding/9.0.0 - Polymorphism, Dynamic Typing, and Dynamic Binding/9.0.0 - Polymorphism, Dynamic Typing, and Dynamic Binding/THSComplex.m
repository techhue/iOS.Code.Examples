//
//  THSComplex.m
//  9.0.0 - Polymorphism, Dynamic Typing, and Dynamic Binding
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import "THSComplex.h"

@implementation THSComplex

@synthesize real, imaginary;
-(void) print
{
    NSLog (@" %g + %gi ", real, imaginary);
}

-(void) setReal: (double) a andImaginary: (double) b
{
    real = a;
    imaginary = b;
}

- (THSComplex *) add: (THSComplex *)f
{
    THSComplex *result = [[THSComplex alloc] init];
    result.real = real + f.real;
    result.imaginary = imaginary + f.imaginary;
    return result;
}

@end
