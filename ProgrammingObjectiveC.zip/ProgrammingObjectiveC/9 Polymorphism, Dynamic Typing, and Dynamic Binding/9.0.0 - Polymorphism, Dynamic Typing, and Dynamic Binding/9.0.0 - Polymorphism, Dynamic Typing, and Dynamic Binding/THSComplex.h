//
//  THSComplex.h
//  9.0.0 - Polymorphism, Dynamic Typing, and Dynamic Binding
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface THSComplex : NSObject

@property double real, imaginary;

-(void) print;
-(void) setReal: (double) a andImaginary: (double) b;
-(THSComplex *) add: (THSComplex *) f;

@end
