//
//  main.m
//  9.0.0 - Polymorphism, Dynamic Typing, and Dynamic Binding
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"
#import "THSFraction.h"
#import "THSComplex.h"

/******************************************************************************
* Polymorphism: Same Name, Different Class
*
*******************************************************************************/

int main(int argc, char *argv[])
{
    @autoreleasepool {
        THSFraction *f1 = [[THSFraction alloc] init];
        THSFraction *f2 = [[THSFraction alloc] init];
        THSFraction *fracResult;
        THSComplex *c1 = [[THSComplex alloc] init];
        THSComplex *c2 = [[THSComplex alloc] init];
        THSComplex *compResult;
        [f1 setTo: 1 over: 10];
        [f2 setTo: 2 over: 15];
        [c1 setReal: 18.0 andImaginary: 2.5];
        [c2 setReal: -5.0 andImaginary: 3.2];
        // add and print 2 complex numbers
        [c1 print];
        NSLog(@"          +");
        [c2 print];
        NSLog(@"-----------");
        compResult = [c1 add:c2];
        [compResult print];
        NSLog(@"\n");
                           // add and print 2 fractions
        [f1 print];
        NSLog (@" +");
        [f2 print];
        NSLog (@"----");
        fracResult = [f1 add: f2];
        [fracResult print];
        }
    return 0;
}
