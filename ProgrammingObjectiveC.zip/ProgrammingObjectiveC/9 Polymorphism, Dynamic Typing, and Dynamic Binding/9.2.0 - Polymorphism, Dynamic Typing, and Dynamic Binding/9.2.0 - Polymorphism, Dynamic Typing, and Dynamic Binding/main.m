//
//  main.m
//  9.2.0 - Polymorphism, Dynamic Typing, and Dynamic Binding
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"
#import "THSSquare.h"

/******************************************************************************
 * Methods for Working with Dynamic Types
 *
 *******************************************************************************/


int main(int argc, char *argv[])
{
    @autoreleasepool {
        THSSquare *mySquare = [[THSSquare alloc] init];
        // isMemberOf:
        if ( [mySquare isMemberOfClass: [THSSquare class]] == YES )
            NSLog (@"mySquare is a member of Square class");
        if ( [mySquare isMemberOfClass: [THSRectangle class]] == YES )
            NSLog (@"mySquare is a member of Rectangle class");
        if ( [mySquare isMemberOfClass: [NSObject class]] == YES )
            NSLog (@"mySquare is a member of NSObject class");
        
        // isKindOf:
        if ( [mySquare isKindOfClass: [THSSquare class]] == YES )
            NSLog (@"mySquare is a kind of Square");
        if ( [mySquare isKindOfClass: [THSRectangle class]] == YES )
            NSLog (@"mySquare is a kind of Rectangle");
        if ( [mySquare isKindOfClass: [NSObject class]] == YES )
            NSLog (@"mySquare is a kind of NSObject");
        
        // respondsTo:
        if ( [mySquare respondsToSelector: @selector (setSide:)] == YES )
            NSLog (@"mySquare responds to setSide: method");
        if ( [mySquare respondsToSelector: @selector (setWidth:andHeight:)] == YES )
            NSLog (@"mySquare responds to setWidth:andHeight: method");
        if ( [THSSquare respondsToSelector: @selector (alloc)] == YES )
            NSLog (@"Square class responds to alloc method");
        
        // instancesRespondTo:
        if ([THSRectangle instancesRespondToSelector: @selector (setSide:)] == YES)
            NSLog (@"Instances of Rectangle respond to setSide: method");
        if ([THSSquare instancesRespondToSelector: @selector (setSide:)] == YES)
            NSLog (@"Instances of Square respond to setSide: method");
        if ([THSSquare isSubclassOfClass: [THSRectangle class]] == YES)
            NSLog (@"Square is a subclass of a rectangle");
    }
    return 0;
}
