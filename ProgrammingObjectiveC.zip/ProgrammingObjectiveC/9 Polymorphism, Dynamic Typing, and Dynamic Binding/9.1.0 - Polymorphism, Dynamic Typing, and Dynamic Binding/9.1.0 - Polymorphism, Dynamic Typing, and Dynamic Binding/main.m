//
//  main.m
//  9.1.0 - Polymorphism, Dynamic Typing, and Dynamic Binding
//
//  Created by naga on 1/3/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "THSAppDelegate.h"

#import "THSAppDelegate.h"
#import "THSFraction.h"
#import "THSComplex.h"

/******************************************************************************
 * Dynamic Binding and the id Type
 *
 *******************************************************************************/


int main(int argc, char *argv[])
{
    @autoreleasepool {
        id dataValue;
        THSFraction *f1 = [[THSFraction alloc] init];
        THSComplex *c1 = [[THSComplex alloc] init];
        [f1 setTo: 2 over: 5];
        [c1 setReal: 10.0 andImaginary: 2.5];
        // first dataValue gets a fraction
        dataValue = f1;
        [dataValue print];
        // now dataValue gets a complex number
        dataValue = c1;
        [dataValue print];
    }
    return 0;
}
