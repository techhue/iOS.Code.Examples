//
//  ViewController.swift
//  Video Task 2
//
//  Created by Sathish Chinniah on 20/11/15.
//  Copyright © 2015 Sathish Chinniah. All rights reserved.
//

import UIKit
import AVFoundation
import MobileCoreServices
import AssetsLibrary
import MediaPlayer
import CoreMedia

class ViewController: UIViewController{
    var Asset1: AVAsset?
    var Asset2: AVAsset?
    var Asset3: AVAsset?
    var audioAsset: AVAsset?
    var loadingAssetOne = false
    
// swt duplicate image for thumbnail image for audio
    @IBOutlet weak var musicImg: UIImageView!

    var videoPlayer = MPMoviePlayerController()
var mediaUI = UIImagePickerController()
    var videoURL = URL(string: "https://www.apple.com")


    override func viewDidLoad() {
        super.viewDidLoad()
        musicImg.isHidden = true
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func startMediaBrowserFromViewController(_ viewController: UIViewController!, usingDelegate delegate : (UINavigationControllerDelegate & UIImagePickerControllerDelegate)!) -> Bool {
        
        if UIImagePickerController.isSourceTypeAvailable(.savedPhotosAlbum) == false {
            return false
        }
        
        let mediaUI = UIImagePickerController()
        mediaUI.sourceType = .savedPhotosAlbum
      
        
        
        mediaUI.mediaTypes = [kUTTypeMovie as String]
        mediaUI.allowsEditing = true
        mediaUI.delegate = delegate
        present(mediaUI, animated: true, completion: nil)
        return true
    }
    
    
// after merge all video and audio. the final video will be saved in gallery and also will display like preview
    func exportDidFinish(_ session: AVAssetExportSession) {
        if session.status == AVAssetExportSessionStatus.completed {
            let outputURL = session.outputURL
            let library = ALAssetsLibrary()
            if library.videoAtPathIs(compatibleWithSavedPhotosAlbum: outputURL) {
                library.writeVideoAtPath(toSavedPhotosAlbum: outputURL,
                    completionBlock: { (assetURL, error) -> Void in
                    
                        if error != nil {
                            
                            print("some files went wrong")

                        } else {
                           
                            // get the output url to display the final video in screen
                            self.videoURL = outputURL!
                            
                            self.mediaUI.dismiss(animated: true, completion: nil)
                            self.videoPlayer = MPMoviePlayerController()
                            self.videoPlayer.contentURL = self.videoURL
                            
                            
                            self.videoPlayer.controlStyle = .embedded
                            
                            self.videoPlayer.scalingMode = .aspectFill
                            
                            self.videoPlayer.shouldAutoplay = true
                            
                            self.videoPlayer.backgroundView.backgroundColor = UIColor.clear
                            self.videoPlayer.isFullscreen = true
                            self.videoPlayer.view.frame = CGRect(x: 38, y: 442, width: 220, height: 106)
                            
                            self.view.addSubview(self.videoPlayer.view)
                            
                            self.videoPlayer.play()
                            self.videoPlayer.prepareToPlay()

                        }

                })
            }
        }
        
    
        Asset1 = nil
        Asset2 = nil
        Asset3 = nil
        audioAsset = nil
    }
    
    
    
    // click first video
    @IBAction func FirstVideo(_ sender: AnyObject) {
                  loadingAssetOne = true
            startMediaBrowserFromViewController(self, usingDelegate: self)
        
    }
    
// clcik second video
    @IBAction func SecondVideo(_ sender: AnyObject) {
       
            loadingAssetOne = false
            startMediaBrowserFromViewController(self, usingDelegate: self)
        
    }
   // click audio
    @IBAction func Audio(_ sender: AnyObject) {
        
        let mediaPickerController = MPMediaPickerController(mediaTypes: .any)
        mediaPickerController.delegate = self
        mediaPickerController.prompt = "Select Audio"
        present(mediaPickerController, animated: true, completion: nil)
    }
    
    
    
    
    
    
    
    @IBAction func playPreview(_ sender: AnyObject) {
        
         startMediaBrowserFromViewController(self, usingDelegate: self)
    }
    
    
    
    
    // orientation for the video
    func orientationFromTransform(_ transform: CGAffineTransform) -> (orientation: UIImageOrientation, isPortrait: Bool) {
        var assetOrientation = UIImageOrientation.up
        var isPortrait = false
        if transform.a == 0 && transform.b == 1.0 && transform.c == -1.0 && transform.d == 0 {
            assetOrientation = .right
            isPortrait = true
        } else if transform.a == 0 && transform.b == -1.0 && transform.c == 1.0 && transform.d == 0 {
            assetOrientation = .left
            isPortrait = true
        } else if transform.a == 1.0 && transform.b == 0 && transform.c == 0 && transform.d == 1.0 {
            assetOrientation = .up
        } else if transform.a == -1.0 && transform.b == 0 && transform.c == 0 && transform.d == -1.0 {
            assetOrientation = .down
        }
        return (assetOrientation, isPortrait)
    }
    
    func videoCompositionInstructionForTrack(_ track: AVCompositionTrack, asset: AVAsset) -> AVMutableVideoCompositionLayerInstruction {
        let instruction = AVMutableVideoCompositionLayerInstruction(assetTrack: track)
        let assetTrack = asset.tracks(withMediaType: AVMediaTypeVideo)[0]
        
        let transform = assetTrack.preferredTransform
        let assetInfo = orientationFromTransform(transform)
        
        var scaleToFitRatio = UIScreen.main.bounds.width / assetTrack.naturalSize.width
        if assetInfo.isPortrait {
            scaleToFitRatio = UIScreen.main.bounds.width / assetTrack.naturalSize.height
            let scaleFactor = CGAffineTransform(scaleX: scaleToFitRatio, y: scaleToFitRatio)
            instruction.setTransform(assetTrack.preferredTransform.concatenating(scaleFactor),
                at: kCMTimeZero)
        } else {
            let scaleFactor = CGAffineTransform(scaleX: scaleToFitRatio, y: scaleToFitRatio)
            var concat = assetTrack.preferredTransform.concatenating(scaleFactor).concatenating(CGAffineTransform(translationX: 0, y: UIScreen.main.bounds.width / 2))
            if assetInfo.orientation == .down {
                let fixUpsideDown = CGAffineTransform(rotationAngle: CGFloat(M_PI))
                let windowBounds = UIScreen.main.bounds
                let yFix = assetTrack.naturalSize.height + windowBounds.height
                let centerFix = CGAffineTransform(translationX: assetTrack.naturalSize.width, y: yFix)
                concat = fixUpsideDown.concatenating(centerFix).concatenating(scaleFactor)
            }
            instruction.setTransform(concat, at: kCMTimeZero)
        }
        
        return instruction
    }
   // merge all file
    @IBAction func MergeAll(_ sender: AnyObject) {
        if let firstAsset = Asset1, let secondAsset = Asset2 {
     
            let mixComposition = AVMutableComposition()
            
            //load first video
            let firstTrack = mixComposition.addMutableTrack(withMediaType: AVMediaTypeVideo,
                preferredTrackID: Int32(kCMPersistentTrackID_Invalid))
            do {
                try firstTrack.insertTimeRange(CMTimeRangeMake(kCMTimeZero, firstAsset.duration),
                    of: firstAsset.tracks(withMediaType: AVMediaTypeVideo)[0] ,
                    at: kCMTimeZero)
            } catch _ {
            }
            // load second video
            let secondTrack = mixComposition.addMutableTrack(withMediaType: AVMediaTypeVideo,
                preferredTrackID: Int32(kCMPersistentTrackID_Invalid))
            do {
                try secondTrack.insertTimeRange(CMTimeRangeMake(kCMTimeZero, secondAsset.duration),
                    of: secondAsset.tracks(withMediaType: AVMediaTypeVideo)[0] ,
                    at: firstAsset.duration)
            } catch _ {
            }
            
            
            let mainInstruction = AVMutableVideoCompositionInstruction()
            mainInstruction.timeRange = CMTimeRangeMake(kCMTimeZero, CMTimeAdd(firstAsset.duration, secondAsset.duration))
            
            let firstInstruction = videoCompositionInstructionForTrack(firstTrack, asset: firstAsset)
            firstInstruction.setOpacity(0.0, at: firstAsset.duration)
            let secondInstruction = videoCompositionInstructionForTrack(secondTrack, asset: secondAsset)
            
            mainInstruction.layerInstructions = [firstInstruction, secondInstruction]
            let mainComposition = AVMutableVideoComposition()
            mainComposition.instructions = [mainInstruction]
            mainComposition.frameDuration = CMTimeMake(1, 30)
            mainComposition.renderSize = CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
            
            //load audio
            if let loadedAudioAsset = audioAsset {
                let audioTrack = mixComposition.addMutableTrack(withMediaType: AVMediaTypeAudio, preferredTrackID: 0)
                do {
                    try audioTrack.insertTimeRange(CMTimeRangeMake(kCMTimeZero, CMTimeAdd(firstAsset.duration, secondAsset.duration)),
                        of: loadedAudioAsset.tracks(withMediaType: AVMediaTypeAudio)[0] ,
                        at: kCMTimeZero)
                } catch _ {
                }
            }
            
          // save the final video to gallery
            let documentDirectory = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
            let dateFormatter = DateFormatter()
            dateFormatter.dateStyle = .long
            dateFormatter.timeStyle = .short
            let date = dateFormatter.string(from: Date())
            // let savePath = documentDirectory.URLByAppendingPathComponent("mergeVideo-\(date).mov")
            
         let savePath = (documentDirectory as NSString).appendingPathComponent("final-\(date).mov")
            
            let url = URL(fileURLWithPath: savePath)
            
            
            let exporter = AVAssetExportSession(asset: mixComposition, presetName: AVAssetExportPresetHighestQuality)
            exporter!.outputURL = url
            exporter!.outputFileType = AVFileTypeQuickTimeMovie
            exporter!.shouldOptimizeForNetworkUse = true
            exporter!.videoComposition = mainComposition
            
            exporter!.exportAsynchronously() {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.exportDidFinish(exporter!)
                })
            }
        }
    }
    
}

extension ViewController: UIImagePickerControllerDelegate {
    
    
    
    // display the first & second video after it picked from gallery
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let mediaType = info[UIImagePickerControllerMediaType] as! NSString
        dismiss(animated: true, completion: nil)
        
        if mediaType == kUTTypeMovie {
            
            let avAsset = AVAsset(url: info[UIImagePickerControllerMediaURL] as! URL)
            
            if loadingAssetOne {
                
                if let vURL = info[UIImagePickerControllerMediaURL] as? URL {
                    self.videoURL = vURL
                } else {
                    print("oops, no url")
                }
                mediaUI.dismiss(animated: true, completion: nil)
                self.videoPlayer = MPMoviePlayerController()
                self.videoPlayer.contentURL = videoURL
                self.videoPlayer.view.frame = CGRect(x: 38, y: 57, width: 220, height: 106)
                self.view.addSubview(self.videoPlayer.view)
                
                self.videoPlayer.controlStyle = .embedded
                
                self.videoPlayer.scalingMode = .aspectFill
           
                
                self.videoPlayer.shouldAutoplay = true
                self.videoPlayer.prepareToPlay()
                self.videoPlayer.play()

                
                Asset1 = avAsset
            } else {
                
                if let vURL = info[UIImagePickerControllerMediaURL] as? URL {
                    self.videoURL = vURL
                } else {
                    print("oops, no url")
                }
                mediaUI.dismiss(animated: true, completion: nil)
                self.videoPlayer = MPMoviePlayerController()
                self.videoPlayer.contentURL = videoURL
                self.videoPlayer.view.frame = CGRect(x: 38, y: 206, width: 220, height: 106)
                self.view.addSubview(self.videoPlayer.view)
                self.videoPlayer.play()
          
                self.videoPlayer.controlStyle = .embedded
                
                self.videoPlayer.scalingMode = .aspectFill
            
                
                self.videoPlayer.shouldAutoplay = true
                self.videoPlayer.prepareToPlay()
            
             
                Asset2 = avAsset
            }
            
        }
        
   
}

            
}
    
    
    
    


extension ViewController: UINavigationControllerDelegate {
    
}

extension ViewController: MPMediaPickerControllerDelegate {
    func mediaPicker(_ mediaPicker: MPMediaPickerController, didPickMediaItems mediaItemCollection: MPMediaItemCollection) {
        let selectedSongs = mediaItemCollection.items
        if selectedSongs.count > 0 {
            let song = selectedSongs[0]
         
            
            if let vURL = song.value(forProperty: MPMediaItemPropertyAssetURL) as? URL {
                audioAsset = AVAsset(url: vURL)

                dismiss(animated: true, completion: nil)
                

                mediaUI.dismiss(animated: true, completion: nil)
                      musicImg.isHidden = false

                
                let alert = UIAlertController(title: "yes", message: "Audio Loaded", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler:nil))
                present(alert, animated: true, completion: nil)
            } else {
                dismiss(animated: true, completion: nil)
                let alert = UIAlertController(title: "No audio", message: "Audio Not Loaded", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler:nil))
                present(alert, animated: true, completion: nil)
            }
        } else {
            dismiss(animated: true, completion: nil)
        }
    }
    
    func mediaPickerDidCancel(_ mediaPicker: MPMediaPickerController) {
        dismiss(animated: true, completion: nil)
    }
}

